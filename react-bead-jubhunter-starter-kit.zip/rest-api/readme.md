# Jobhunter API

```
POST /authenticate

POST /users
GET/PATCH/PUT/DELETE /users/:id

GET/POST /experiences
GET/PATCH/PUT/DELETE /experiences/:id


```